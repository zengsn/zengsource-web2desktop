#!/bin/sh
java -jar -XstartOnFirstThread web2desktop.jar